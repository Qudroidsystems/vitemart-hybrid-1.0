<!-- JAVASCRIPT -->
<script src="{{ asset('theme/layouts/assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('theme/layouts/assets/libs/simplebar/simplebar.min.js') }}"></script>
<script src="{{ asset('theme/layouts/assets/js/plugins.js') }}"></script>
<!-- list.js min js -->
<script src="{{ asset('theme/layouts/assets/libs/list.js/list.min.js') }}"></script>
<script src="{{ asset('theme/layouts/assets/libs/list.pagination.js/list.pagination.min.js') }}"></script>
<!-- sweetalert2 js -->
<script src="{{ asset('theme/layouts/assets/libs/sweetalert2/sweetalert2.min.js') }}"></script>
<!-- dropzone js -->
<script src="{{ asset('theme/layouts/assets/libs/dropzone/dropzone-min.js') }}"></script>
<script src="{{ asset('vendor/choices/choices.min.js') }}"></script>
<!-- Axios -->
<script src="{{ asset('vendor/axios/axios.min.js') }}"></script>


<!-- User list init js (load after list.js and dependencies) -->
<script src="{{ asset('theme/layouts/assets/js/pages/banner-list.init.js') }}"></script>
<!-- App js -->
<script src="{{ asset('theme/layouts/assets/js/app.js') }}"></script>

