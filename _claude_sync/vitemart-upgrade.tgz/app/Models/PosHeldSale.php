<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PosHeldSale extends Model
{
    protected $fillable = ['user_id', 'label', 'customer_id', 'cart', 'total'];

    protected $casts = ['cart' => 'array', 'total' => 'decimal:2'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }
}
